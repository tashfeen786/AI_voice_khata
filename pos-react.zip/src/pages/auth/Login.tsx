import { FormEvent, useState } from "react";
import { useNavigate, useLocation, Navigate } from "react-router-dom";
import { Eye, EyeOff, Loader2, Store } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/contexts/AuthContext";
import { tokenStore } from "@/lib/api/token-store";

export default function Login() {
  const { login, isAuthenticated, isLoading } = useAuth();
  const nav = useNavigate();
  const loc = useLocation() as { state?: { from?: string } };

  const [username, setUsername] = useState(tokenStore.getRememberedUsername() ?? "");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(!!tokenStore.getRememberedUsername());
  const [tenantName, setTenantName] = useState<string>(tokenStore.getTenant() ?? "");
  const [submitting, setSubmitting] = useState(false);

  if (isAuthenticated && !isLoading) return <Navigate to={loc.state?.from ?? "/"} replace />;

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      // Pass tenant name (empty/null for host login)
      const tenantValue = tenantName.trim() || null;
      const info = await login(username.trim(), password, tenantValue, remember);
      toast.success(`Welcome back, ${info.name}`);
      const dest = info.tenantId == null ? "/" : "/";
      nav(loc.state?.from ?? dest, { replace: true });
    } catch (err: any) {
      const msg = err?.response?.data?.error_description ?? err?.response?.data?.error ?? "Invalid username or password";
      toast.error(typeof msg === "string" ? msg : "Login failed");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background">
      {/* Brand panel */}
      <div className="hidden lg:flex relative overflow-hidden bg-sidebar text-sidebar-foreground p-12 flex-col justify-between">
        <div className="absolute inset-0 opacity-80" style={{ background: "var(--gradient-hero)" }} />
        <div className="relative">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 rounded-2xl bg-gradient-primary grid place-items-center shadow-glow">
              <Store className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <div className="font-display font-bold text-xl text-white leading-none">SmartDukaan</div>
              <div className="text-xs text-sidebar-foreground/70 mt-1">AI POS · Udhaar · Stock</div>
            </div>
          </div>
        </div>
        <div className="relative space-y-4 max-w-sm">
          <h2 className="font-display text-3xl font-bold text-white leading-tight">
            Apni dukaan, smart andaaz mein.
          </h2>
          <p className="font-urdu text-2xl text-white/90 leading-snug">
            تیز بلنگ، ادھار کا ریکارڈ، اور اسٹاک — سب ایک جگہ۔
          </p>
          <ul className="text-sm text-sidebar-foreground/80 space-y-2 pt-4">
            <li>• One-tap POS billing with WhatsApp invoices</li>
            <li>• Customer udhaar (credit) tracking</li>
            <li>• Live inventory + AI sales insights</li>
          </ul>
        </div>
        <div className="relative text-xs text-sidebar-foreground/50">© SmartDukaan {new Date().getFullYear()}</div>
      </div>

      {/* Form panel */}
      <div className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-3 mb-8">
            <div className="h-10 w-10 rounded-2xl bg-gradient-primary grid place-items-center shadow-glow">
              <Store className="h-5 w-5 text-primary-foreground" />
            </div>
            <div className="font-display font-bold text-lg">SmartDukaan</div>
          </div>

          <h1 className="font-display text-3xl font-bold mb-1">Sign in</h1>
          <p className="text-sm text-muted-foreground mb-1">Welcome back. Let's open the shop.</p>
          <p className="font-urdu text-sm text-muted-foreground mb-8">خوش آمدید، اپنی دکان میں داخل ہوں</p>

          <form onSubmit={onSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="tenant">Shop / Tenant Name</Label>
              <Input
                id="tenant"
                value={tenantName}
                onChange={e => setTenantName(e.target.value)}
                className="h-11 rounded-xl bg-secondary border-0"
                placeholder="Leave empty for Host login, or type tenant name (e.g., Default)"
              />
              <p className="text-xs text-muted-foreground">Leave empty to login as Host, or enter your shop/tenant name</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input id="username" autoComplete="username" required value={username}
                onChange={e => setUsername(e.target.value)}
                className="h-11 rounded-xl bg-secondary border-0" placeholder="admin" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <button type="button" className="text-xs text-primary hover:underline" onClick={() => toast.info("Password reset coming soon")}>
                  Forgot?
                </button>
              </div>
              <div className="relative">
                <Input id="password" type={showPassword ? "text" : "password"} autoComplete="current-password" required
                  value={password} onChange={e => setPassword(e.target.value)}
                  className="h-11 rounded-xl bg-secondary border-0 pr-10" placeholder="••••••••" />
                <button type="button" onClick={() => setShowPassword(s => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <label className="flex items-center gap-2 text-sm text-muted-foreground select-none cursor-pointer">
              <Checkbox checked={remember} onCheckedChange={(v) => setRemember(!!v)} />
              Remember my username
            </label>

            <Button type="submit" disabled={submitting}
              className="w-full h-11 rounded-xl bg-gradient-primary text-primary-foreground hover:opacity-95 shadow-glow font-semibold">
              {submitting ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Signing in…</> : "Sign in"}
            </Button>

            <div className="rounded-xl bg-secondary/60 border border-border/60 p-3 text-xs text-muted-foreground space-y-1">
              <div className="font-medium text-foreground">Test accounts</div>
              <div>Host: <code className="text-foreground">admin</code> / <code>1q2w3E*</code> (no tenant)</div>
              <div>Tenant admin: <code className="text-foreground">shopkeeper</code> / <code>1q2w3E*</code> (Default)</div>
              <div>Cashier: <code className="text-foreground">cashier</code> / <code>1q2w3E*</code> (Default)</div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}