// Mock ABP/OpenIddict backend. Swap to real API by removing the adapter
// in api-client.ts (the `mockAdapter` line) and setting VITE_API_URL.

import type { AxiosRequestConfig } from "axios";

export interface MockUser {
  id: string;
  userName: string;
  password: string;
  email: string;
  name: string;
  surname: string;
  phoneNumber?: string;
  tenantId: string | null; // null = host
  roles: string[];
  permissions: string[];
}

export interface MockTenant {
  id: string;
  name: string;
  features: string[];
}

const tenants: MockTenant[] = [
  { id: "default", name: "Default", features: ["POS.Billing", "Ledger.Udhaar", "Inventory", "Reports", "WhatsApp"] },
  { id: "kiryana-rashid", name: "Rashid Kiryana", features: ["POS.Billing", "Ledger.Udhaar", "Inventory"] },
  { id: "mobile-zone", name: "Mobile Zone", features: ["POS.Billing", "Inventory", "Reports"] },
];

const users: MockUser[] = [
  {
    id: "u-host",
    userName: "admin",
    password: "1q2w3E*",
    email: "admin@smartdukaan.app",
    name: "Host",
    surname: "Admin",
    phoneNumber: "+92 300 0000000",
    tenantId: null,
    roles: ["host-admin"],
    permissions: ["AbpIdentity.Users", "AbpTenantManagement.Tenants", "FeatureManagement.ManageHostFeatures", "Dashboard.View"],
  },
  {
    id: "u-tenant-admin",
    userName: "shopkeeper",
    password: "1q2w3E*",
    email: "rashid@kiryana.pk",
    name: "Rashid",
    surname: "Ahmed",
    phoneNumber: "+92 321 1234567",
    tenantId: "default",
    roles: ["tenant-admin"],
    permissions: ["Dashboard.View", "POS.Create", "Customers.Manage", "Inventory.Manage", "Reports.View"],
  },
  {
    id: "u-cashier",
    userName: "cashier",
    password: "1q2w3E*",
    email: "salman@kiryana.pk",
    name: "Salman",
    surname: "Ali",
    phoneNumber: "+92 333 7654321",
    tenantId: "default",
    roles: ["cashier"],
    permissions: ["POS.Create"],
  },
];

const accessTokens = new Map<string, string>(); // token -> userId
const refreshTokens = new Map<string, string>(); // refresh -> userId

function makeToken(prefix: string) {
  return `${prefix}.${Math.random().toString(36).slice(2)}.${Date.now().toString(36)}`;
}

function readBody(data: any): Record<string, string> {
  if (!data) return {};
  if (typeof data === "string") {
    return Object.fromEntries(new URLSearchParams(data));
  }
  if (data instanceof URLSearchParams) {
    return Object.fromEntries(data);
  }
  if (typeof data === "object") return data;
  return {};
}

function jsonResponse(config: AxiosRequestConfig, status: number, data: any) {
  return {
    data,
    status,
    statusText: status === 200 ? "OK" : "Error",
    headers: { "content-type": "application/json" },
    config: config as any,
  };
}

async function delay(ms = 250) {
  return new Promise(res => setTimeout(res, ms));
}

function getUserFromAuth(config: AxiosRequestConfig): MockUser | null {
  const auth = (config.headers?.Authorization || config.headers?.authorization) as string | undefined;
  if (!auth?.startsWith("Bearer ")) return null;
  const token = auth.slice(7);
  const userId = accessTokens.get(token);
  return users.find(u => u.id === userId) ?? null;
}

export async function mockAdapter(config: AxiosRequestConfig) {
  await delay();
  const url = (config.url || "").replace(/^https?:\/\/[^/]+/, "");
  const method = (config.method || "get").toLowerCase();

  // ===== /connect/token =====
  if (url.startsWith("/connect/token") && method === "post") {
    const body = readBody(config.data);
    const tenantHeader = (config.headers?.["__tenant"] as string | undefined) ?? null;

    if (body.grant_type === "refresh_token") {
      const userId = refreshTokens.get(body.refresh_token);
      if (!userId) return Promise.reject({ response: jsonResponse(config, 400, { error: "invalid_grant" }) });
      const user = users.find(u => u.id === userId)!;
      const access = makeToken("at");
      const refresh = makeToken("rt");
      accessTokens.set(access, user.id);
      refreshTokens.delete(body.refresh_token);
      refreshTokens.set(refresh, user.id);
      return jsonResponse(config, 200, {
        access_token: access, refresh_token: refresh, expires_in: 3600, token_type: "Bearer",
      });
    }

    if (body.grant_type === "password") {
      const user = users.find(u => u.userName === body.username && u.password === body.password);
      if (!user) {
        return Promise.reject({ response: jsonResponse(config, 400, { error: "invalid_grant", error_description: "Invalid username or password" }) });
      }
      // Tenant check: tenant users must match the __tenant header (if provided), host must have no tenant header.
      if (user.tenantId && tenantHeader && tenantHeader !== user.tenantId && tenantHeader !== tenants.find(t => t.id === user.tenantId)?.name) {
        return Promise.reject({ response: jsonResponse(config, 400, { error: "invalid_grant", error_description: "Wrong tenant for this user" }) });
      }
      if (!user.tenantId && tenantHeader) {
        return Promise.reject({ response: jsonResponse(config, 400, { error: "invalid_grant", error_description: "Host users must not select a tenant" }) });
      }
      const access = makeToken("at");
      const refresh = makeToken("rt");
      accessTokens.set(access, user.id);
      refreshTokens.set(refresh, user.id);
      return jsonResponse(config, 200, {
        access_token: access, refresh_token: refresh, expires_in: 3600, token_type: "Bearer",
      });
    }

    return Promise.reject({ response: jsonResponse(config, 400, { error: "unsupported_grant_type" }) });
  }

  // ===== /connect/userinfo =====
  if (url.startsWith("/connect/userinfo") && method === "get") {
    const user = getUserFromAuth(config);
    if (!user) return Promise.reject({ response: jsonResponse(config, 401, { error: "unauthorized" }) });
    return jsonResponse(config, 200, {
      sub: user.id, name: user.name, family_name: user.surname,
      preferred_username: user.userName, email: user.email,
      phone_number: user.phoneNumber, tenantid: user.tenantId,
      role: user.roles,
    });
  }

  // ===== /connect/logout =====
  if (url.startsWith("/connect/logout")) {
    const auth = config.headers?.Authorization as string | undefined;
    if (auth?.startsWith("Bearer ")) accessTokens.delete(auth.slice(7));
    return jsonResponse(config, 200, {});
  }

  // ===== Tenants list (for login dropdown / host switcher) =====
  if (url.startsWith("/api/abp/multi-tenancy/tenants") && method === "get") {
    return jsonResponse(config, 200, { items: tenants, totalCount: tenants.length });
  }

  // ===== Profile =====
  if (url.startsWith("/api/account/my-profile")) {
    const user = getUserFromAuth(config);
    if (!user) return Promise.reject({ response: jsonResponse(config, 401, { error: "unauthorized" }) });
    if (method === "get") {
      return jsonResponse(config, 200, {
        userName: user.userName, email: user.email, name: user.name,
        surname: user.surname, phoneNumber: user.phoneNumber,
      });
    }
    if (method === "put") {
      const body = readBody(typeof config.data === "string" ? JSON.parse(config.data) : config.data);
      Object.assign(user, {
        name: body.name ?? user.name,
        surname: body.surname ?? user.surname,
        phoneNumber: body.phoneNumber ?? user.phoneNumber,
        email: body.email ?? user.email,
      });
      return jsonResponse(config, 200, {
        userName: user.userName, email: user.email, name: user.name,
        surname: user.surname, phoneNumber: user.phoneNumber,
      });
    }
  }

  // ===== Change password =====
  if (url.startsWith("/api/account/my-password/change") && method === "post") {
    const user = getUserFromAuth(config);
    if (!user) return Promise.reject({ response: jsonResponse(config, 401, { error: "unauthorized" }) });
    const body = typeof config.data === "string" ? JSON.parse(config.data) : config.data;
    if (body.currentPassword !== user.password) {
      return Promise.reject({ response: jsonResponse(config, 400, { error: { message: "Current password is incorrect" } }) });
    }
    user.password = body.newPassword;
    return jsonResponse(config, 204, null);
  }

  // ===== Permissions =====
  if (url.startsWith("/api/permission-management/permissions") && method === "get") {
    const user = getUserFromAuth(config);
    if (!user) return Promise.reject({ response: jsonResponse(config, 401, { error: "unauthorized" }) });
    return jsonResponse(config, 200, {
      groups: [{
        name: "SmartDukaan",
        permissions: user.permissions.map(name => ({ name, isGranted: true })),
      }],
    });
  }

  // ===== Features =====
  if (url.startsWith("/api/feature-management/features") && method === "get") {
    const user = getUserFromAuth(config);
    if (!user) return Promise.reject({ response: jsonResponse(config, 401, { error: "unauthorized" }) });
    const tenant = tenants.find(t => t.id === user.tenantId) ?? null;
    const enabled = tenant?.features ?? ["POS.Billing", "Ledger.Udhaar", "Inventory", "Reports", "WhatsApp"];
    return jsonResponse(config, 200, {
      groups: [{
        name: "SmartDukaan",
        features: enabled.map(name => ({ name, value: "true" })),
      }],
    });
  }

  // ===== SaaS Editions (Host-only) =====
  const mockEditions = [
    { id: "edition-free", displayName: "Free", concurrencyStamp: "abc123" },
    { id: "edition-standard", displayName: "Standard", concurrencyStamp: "def456" },
    { id: "edition-premium", displayName: "Premium", concurrencyStamp: "ghi789" },
  ];

  if (url.startsWith("/api/saas/editions")) {
    const user = getUserFromAuth(config);
    if (!user) return Promise.reject({ response: jsonResponse(config, 401, { error: "unauthorized" }) });
    // Host only
    if (user.tenantId !== null) {
      return Promise.reject({ response: jsonResponse(config, 403, { error: "forbidden", message: "Host-only endpoint" }) });
    }

    // GET /api/saas/editions/all
    if (url === "/api/saas/editions/all" && method === "get") {
      return jsonResponse(config, 200, mockEditions);
    }

    // GET /api/saas/editions (paged)
    if (url === "/api/saas/editions" && method === "get") {
      const params = new URLSearchParams(url.includes("?") ? url.split("?")[1] : "");
      const skip = parseInt(params.get("SkipCount") || "0", 10);
      const max = parseInt(params.get("MaxResultCount") || "100", 10);
      return jsonResponse(config, 200, {
        items: mockEditions.slice(skip, skip + max),
        totalCount: mockEditions.length,
      });
    }

    // POST /api/saas/editions
    if (url === "/api/saas/editions" && method === "post") {
      const body = typeof config.data === "string" ? JSON.parse(config.data) : config.data;
      const newEdition = {
        id: `edition-${Date.now()}`,
        displayName: body.displayName || "New Edition",
        concurrencyStamp: `stamp-${Date.now()}`,
      };
      mockEditions.push(newEdition);
      return jsonResponse(config, 200, newEdition);
    }

    // PUT /api/saas/editions/:id
    const editionPutMatch = url.match(/^\/api\/saas\/editions\/([^/]+)$/);
    if (editionPutMatch && method === "put") {
      const id = editionPutMatch[1];
      const body = typeof config.data === "string" ? JSON.parse(config.data) : config.data;
      const idx = mockEditions.findIndex(e => e.id === id);
      if (idx === -1) return Promise.reject({ response: jsonResponse(config, 404, { error: "not_found" }) });
      mockEditions[idx] = { ...mockEditions[idx], displayName: body.displayName, concurrencyStamp: body.concurrencyStamp };
      return jsonResponse(config, 200, mockEditions[idx]);
    }

    // DELETE /api/saas/editions/:id
    const editionDeleteMatch = url.match(/^\/api\/saas\/editions\/([^/]+)$/);
    if (editionDeleteMatch && method === "delete") {
      const id = editionDeleteMatch[1];
      const idx = mockEditions.findIndex(e => e.id === id);
      if (idx === -1) return Promise.reject({ response: jsonResponse(config, 404, { error: "not_found" }) });
      mockEditions.splice(idx, 1);
      return jsonResponse(config, 204, null);
    }
  }

  return Promise.reject({ response: jsonResponse(config, 404, { error: "not_found", path: url }) });
}

export const mockMeta = { tenants };