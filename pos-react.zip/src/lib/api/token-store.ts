// In-memory access token (safer against XSS) + refresh token in localStorage.
// On hard reload, we lose the access token and use the refresh token to mint a new one.

const REFRESH_KEY = "smartdukaan.refresh_token";
const TENANT_KEY = "smartdukaan.tenant";
const REMEMBER_KEY = "smartdukaan.remember_username";

let accessToken: string | null = null;
let accessTokenExpiresAt = 0;

type Listener = (token: string | null) => void;
const listeners = new Set<Listener>();

export const tokenStore = {
  getAccessToken: () => accessToken,
  getAccessTokenExpiresAt: () => accessTokenExpiresAt,
  setAccessToken(token: string | null, expiresInSeconds = 3600) {
    accessToken = token;
    accessTokenExpiresAt = token ? Date.now() + expiresInSeconds * 1000 : 0;
    listeners.forEach(l => l(token));
  },
  getRefreshToken: () => localStorage.getItem(REFRESH_KEY),
  setRefreshToken(token: string | null) {
    if (token) localStorage.setItem(REFRESH_KEY, token);
    else localStorage.removeItem(REFRESH_KEY);
  },
  getTenant: () => localStorage.getItem(TENANT_KEY),
  setTenant(tenant: string | null) {
    if (tenant) localStorage.setItem(TENANT_KEY, tenant);
    else localStorage.removeItem(TENANT_KEY);
  },
  getRememberedUsername: () => localStorage.getItem(REMEMBER_KEY),
  setRememberedUsername(username: string | null) {
    if (username) localStorage.setItem(REMEMBER_KEY, username);
    else localStorage.removeItem(REMEMBER_KEY);
  },
  clear() {
    accessToken = null;
    accessTokenExpiresAt = 0;
    localStorage.removeItem(REFRESH_KEY);
    listeners.forEach(l => l(null));
  },
  subscribe(l: Listener) {
    listeners.add(l);
    return () => listeners.delete(l);
  },
};