import axios, { AxiosError, AxiosRequestConfig, InternalAxiosRequestConfig } from "axios";
import { toast } from "sonner";
import { tokenStore } from "./token-store";

export const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "https://localhost:44323",
  headers: { "Content-Type": "application/json" },
});

// ===== Request interceptor: attach Bearer + __tenant =====
apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = tokenStore.getAccessToken();
  const tenant = tokenStore.getTenant();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  const skipTenant = (config.headers as any)?.["X-Skip-Tenant"];
  if (skipTenant) {
    delete (config.headers as any)["__tenant"];
    delete (config.headers as any)["X-Skip-Tenant"];
  } else if (tenant) {
    config.headers["__tenant"] = tenant;
  }
  return config;
});

// ===== Refresh queue =====
let refreshPromise: Promise<string | null> | null = null;

async function refreshAccessToken(): Promise<string | null> {
  const refresh = tokenStore.getRefreshToken();
  if (!refresh) return null;
  try {
    const body = new URLSearchParams({ 
      grant_type: "refresh_token", 
      refresh_token: refresh,
      client_id: "App_App"
    });
    const res = await axios.request({
      url: "/connect/token",
      baseURL: apiClient.defaults.baseURL,
      method: "post",
      data: body,
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });
    tokenStore.setAccessToken(res.data.access_token, res.data.expires_in);
    tokenStore.setRefreshToken(res.data.refresh_token);
    return res.data.access_token;
  } catch {
    tokenStore.clear();
    return null;
  }
}

// ===== Response interceptor: 401 refresh, 403 toast =====
apiClient.interceptors.response.use(
  res => res,
  async (error: AxiosError) => {
    const original = error.config as (AxiosRequestConfig & { _retried?: boolean }) | undefined;
    const status = error.response?.status;

    if (status === 401 && original && !original._retried && !original.url?.includes("/connect/token")) {
      original._retried = true;
      refreshPromise = refreshPromise ?? refreshAccessToken();
      const newToken = await refreshPromise;
      refreshPromise = null;
      if (newToken) {
        original.headers = original.headers || {};
        (original.headers as Record<string, string>).Authorization = `Bearer ${newToken}`;
        return apiClient.request(original);
      }
      tokenStore.clear();
      if (typeof window !== "undefined" && !window.location.pathname.startsWith("/login")) {
        toast.warning("Session expired. Please sign in again.");
        window.location.href = "/login";
      }
    }

    if (status === 403) {
      toast.error("Permission denied");
    }

    return Promise.reject(error);
  }
);

export { refreshAccessToken };