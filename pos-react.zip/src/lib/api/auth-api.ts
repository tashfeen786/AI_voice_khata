import { apiClient } from "./api-client";

export interface TokenResponse {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  token_type: "Bearer";
}

export interface UserInfo {
  sub: string;
  name: string;
  family_name: string;
  preferred_username: string;
  email: string;
  phone_number?: string;
  tenantid: string | null;
  role: string[];
  enabled_features?: string; // Comma-separated list of enabled feature names
}

export interface ProfileDto {
  userName: string;
  email: string;
  name: string;
  surname: string;
  phoneNumber?: string;
}

export interface TenantDto { id: string; name: string; features?: string[] }

export interface SessionDto {
  id: string;
  userName?: string;
  email?: string;
  name?: string;
  surname?: string;
  phoneNumber?: string;
  tenantId?: string;
  isHost: boolean;
  enabledFeatures: string[];
  permissions: string[];
}

export async function loginWithPassword(username: string, password: string, tenant: string | null) {
  const body = new URLSearchParams({
    grant_type: "password",
    client_id: "App_App",
    username,
    password,
    scope: "offline_access openid profile email phone roles App",
  });
  const res = await apiClient.post<TokenResponse>("/connect/token", body, {
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      ...(tenant ? { "__tenant": tenant } : {}),
    },
  });
  return res.data;
}

export async function getUserInfo() {
  const res = await apiClient.get<UserInfo>("/connect/userinfo");
  return res.data;
}

export async function logoutApi() {
  // Server logout endpoint not configured in ABP
  // Tokens are cleared client-side in AuthContext
  // JWT tokens expire naturally, no server revocation needed
}

export async function getProfile() {
  const res = await apiClient.get<ProfileDto>("/api/app/profile");
  return res.data;
}

export async function updateProfile(profile: Partial<ProfileDto>) {
  const res = await apiClient.put<ProfileDto>("/api/app/profile", profile);
  return res.data;
}

export async function changePassword(currentPassword: string, newPassword: string) {
  await apiClient.post("/api/app/profile/change-password", { currentPassword, newPassword });
}

export async function getPermissions(userId: string, roles: string[] = []): Promise<string[]> {
  const grantedPerms = new Set<string>();
  
  // Use single-letter provider codes that match ABP database (U=User, R=Role)
  try {
    // Fetch user-specific permissions
    const userRes = await apiClient.get("/api/permission-management/permissions", {
      params: { providerName: "U", providerKey: userId },
    });
    const userGroups = userRes.data?.groups ?? [];
    userGroups.flatMap((g: any) => g.permissions ?? [])
      .filter((p: any) => p.isGranted)
      .forEach((p: any) => grantedPerms.add(p.name));
  } catch (err: any) {
    console.warn("Failed to fetch user permissions", err.response?.status);
  }
  
  // Fetch role-based permissions
  for (const role of roles) {
    try {
      const roleRes = await apiClient.get("/api/permission-management/permissions", {
        params: { providerName: "R", providerKey: role },
      });
      const roleGroups = roleRes.data?.groups ?? [];
      roleGroups.flatMap((g: any) => g.permissions ?? [])
        .filter((p: any) => p.isGranted)
        .forEach((p: any) => grantedPerms.add(p.name));
    } catch (err: any) {
      console.warn(`Failed to fetch permissions for role ${role}`, err.response?.status);
    }
  }
  
  return Array.from(grantedPerms);
}

export async function getSession(): Promise<SessionDto> {
  const res = await apiClient.get<SessionDto>("/api/app/session");
  return res.data;
}

export async function listTenants(): Promise<TenantDto[]> {
  // Correct endpoint from Swagger: /api/multi-tenancy/tenants
  const res = await apiClient.get("/api/multi-tenancy/tenants", {
    params: { MaxResultCount: 100 }
  });
  return res.data?.items ?? [];
}